#!/system/bin/sh
# 卸载时恢复：删掉本模块写过的刷新率设置，调度切回 schedutil
settings delete system peak_refresh_rate
settings delete system min_refresh_rate
settings delete global peak_refresh_rate
for p in /sys/devices/system/cpu/cpufreq/policy*; do
  [ -w "$p/scaling_governor" ] && echo schedutil > "$p/scaling_governor"
done
[ -w /sys/class/kgsl/kgsl-3d0/devfreq/governor ] && echo msm-adreno-tz > /sys/class/kgsl/kgsl-3d0/devfreq/governor

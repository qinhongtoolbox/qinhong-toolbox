#!/system/bin/sh
# 秦红帧率优化 · late_start 服务脚本（root 由面具执行）
# 等待开机完成
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 2; done
sleep 3
# 屏幕刷新率顶到面板最高档（120Hz 面板即 120）
settings put system peak_refresh_rate 120.0
settings put system min_refresh_rate 120.0
settings put global peak_refresh_rate 120.0
# CPU 调度切性能模式（所有 policy）
for p in /sys/devices/system/cpu/cpufreq/policy*; do
  [ -w "$p/scaling_governor" ] && echo performance > "$p/scaling_governor"
done
# GPU 调度（高通路径，存在才写；联发科无此路径自动跳过）
[ -w /sys/class/kgsl/kgsl-3d0/devfreq/governor ] && echo performance > /sys/class/kgsl/kgsl-3d0/devfreq/governor
